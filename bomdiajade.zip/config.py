# Keys do bot

consumer_key = "a3s78XSJEYxKpOT0h0bIT1VSX"
consumer_secret = "UUvFIaed2dm7jreLRmbNOlxloNoyrzOAtU6UV0gyNzSv9DQQ2Q"

access_token = "1360217583375568897-PffmfByEzwbhfSWVpZJ8Nup99SopwK"
access_token_secret = "cNzaBY8tEAiwVoIxEoxgdN8ANcdhyQC24CqiRJ335qBRd"